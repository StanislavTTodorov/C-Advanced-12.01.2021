﻿using System;
using System.Collections.Generic;

namespace _5GenericCountMethodStrings
{
    public class Program
    {
        static void Main(string[] args)
        {
            int lineOfRead = int.Parse(Console.ReadLine());
            Box<string> boxs = new Box<string>();
            for (int i = 0; i < lineOfRead; i++)
            {
                string input = Console.ReadLine();
                boxs.Add(input);
            }
            Console.WriteLine(boxs.GetCount(Console.ReadLine()));
        }              
    }
}
