﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IteratorsAndComparators
{
    public class Book
    {
        public Book(string titel,int year,params string[] authors)
        {
            Titel = titel;
            Year = year;
            Authors = authors;
        }
        public string Titel { get; private set; }

        public int Year { get; private set; }

        public IReadOnlyList<string> Authors { get; private set; }

    }
}
