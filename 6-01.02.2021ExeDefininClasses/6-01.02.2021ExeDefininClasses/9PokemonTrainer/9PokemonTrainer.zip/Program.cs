﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _9PokemonTrainer
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Pokemon> pokemons = new List<Pokemon>();
            List<Trainer> trainers = new List<Trainer>();
            string input = Console.ReadLine();
            while (input != "Tournament")
            {
                string[] trainerInfo = input.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                string name = trainerInfo[0];
                string pokemonName = trainerInfo[1];
                string element = trainerInfo[2];
                double health = double.Parse(trainerInfo[3]);
                
                if (trainers.Exists(n=>n.Name == name))
                {
                    Trainer trainer = trainers.Where(n => n.Name == name).First();
                    trainer.CollectionOfPokemon += 1;
                }
                else
                {
                    Trainer trainer = new Trainer(name);
                    trainers.Add(trainer);
                }

                Pokemon pokemon = new Pokemon(pokemonName, element, health, name);
                pokemons.Add(pokemon);
                input = Console.ReadLine();
            }
            input = Console.ReadLine();
            List<string> deletedPokemonList = new List<string>();
            List<string> treinerName = new List<string>();
            while (input!="End")
            {
                bool isHavePokemon = false;
                if (input == "Fire" || input== "Water" || input== "Electricity")
                {
                    foreach (var trainer in trainers)
                    {
                        foreach (var element in pokemons.Where(n => n.Name==trainer.Name))
                        {
                            if (element.Element == input)
                            {
                                trainer.Badges += 1;
                                isHavePokemon = true;
                                break;
                            }
                        }
                        if (isHavePokemon)
                        {
                            break;
                        }
                    }
                }
                if (isHavePokemon==false)
                {
                    foreach (var trainer in trainers)
                    {
                        foreach (var pokemon in pokemons.Where(n => n.Name == trainer.Name))
                        {
                            pokemon.Health -= 10;
                            if (pokemon.Health<=0)
                            {
                                treinerName.Add(pokemon.Name);
                                deletedPokemonList.Add(pokemon.PokemonName);
                            }
                        }
                    }
                }
                if (deletedPokemonList.Count>0)
                {
                    foreach (var name in deletedPokemonList)
                    {
                        if (pokemons.Exists(n=>n.PokemonName==name))
                        {
                           
                            int index = pokemons.FindIndex(0,(n => n.PokemonName == name));
                            pokemons.RemoveAt(index);
                        }
                    }
                  deletedPokemonList.Clear();
                    foreach (var name in treinerName)
                    {
                        if (trainers.Exists(n=>n.Name==name))
                        {
                            int index = trainers.FindIndex(0, (n => n.Name == name));
                            trainers[index].CollectionOfPokemon -= 1;
                        }
                    }
                    treinerName.Clear();
                }
                input = Console.ReadLine();
            }
            foreach (var item in trainers.OrderByDescending(n=>n.Badges))
            {
                Console.WriteLine($"{item.Name} {item.Badges} {item.CollectionOfPokemon}");
            }
        }
    }
}
