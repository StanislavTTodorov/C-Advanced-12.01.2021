﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _9PokemonTrainer
{
    class Trainer
    {
        public Trainer(string name )//,string pokemonName,string element,double health)
        {
            Name = name;
            Badges = 0;
            CollectionOfPokemon = 1;
           // Pokemon = new Pokemon(pokemonName, element, health);
        }
        public string Name { get; set; }

        public int Badges { get; set; }

        public int CollectionOfPokemon { get; set; }

        //public Pokemon Pokemon { get; set; }
    }
}
